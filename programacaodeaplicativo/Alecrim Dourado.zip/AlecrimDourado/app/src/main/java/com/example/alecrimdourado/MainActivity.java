package com.example.alecrimdourado;

import static com.example.alecrimdourado.R.id.login;
import static com.example.alecrimdourado.R.id.senha;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText campo, senha;
    TextView exibe;
    ArrayList<Usuario> usu = new ArrayList<>();
    Usuario encontrado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        campo = findViewById(R.id.login);
        exibe = findViewById(R.id.texto);
        senha = findViewById(R.id.senha);
        Usuario u = new Usuario("ari", "123", 1);
        Usuario u2 = new Usuario("ali", "456", 2);
        usu.add(u);
        usu.add(u2);
    }

    public void clica(View v) {
        if (verificaUsuario(campo.getText().toString(), senha.getText().toString())) {
            String texto = campo.getText().toString();
            Toast.makeText(this, "Bem Vindo, " + texto, Toast.LENGTH_LONG).show();
            exibe.setText(texto);
            campo.setText(null);
            if (encontrado.perfil == 1) {
                mudaTela();
            }
            else if (encontrado.perfil == 2) {
                Tela_Admin.list = usu;
                mudaTelaAdmin();
            }

        } else {
            Toast.makeText(this, "Usuário ou senha incorreta", Toast.LENGTH_LONG).show();
        }
    }

    public void mudaTela() {
        Intent i = new Intent(this, tela1.class);
        startActivity(i);
    }

    public void mudaTelaAdmin() {
        Intent t = new Intent(this, Tela_Admin.class);
        startActivity(t);
    }

    public boolean verificaUsuario(String login, String senha) {
        for (Usuario pessoa : usu) {
            if (login.equals(pessoa.login) && senha.equals(pessoa.senha)) {
                encontrado = pessoa;
                return true;
            }
        }
        return false;
    }
}