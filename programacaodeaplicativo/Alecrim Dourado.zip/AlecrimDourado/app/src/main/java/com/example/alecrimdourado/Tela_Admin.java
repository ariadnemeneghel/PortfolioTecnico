package com.example.alecrimdourado;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class Tela_Admin extends AppCompatActivity {
    EditText login, senha;
    CheckBox adm;
    static ArrayList<Usuario> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_admin);
        login = findViewById(R.id.nuLogin);
        senha = findViewById(R.id.segredo);
        adm = findViewById(R.id.selecao);
    }
    public void cadastro(View c){
        String l = login.getText().toString();
        String s = senha.getText().toString();
        if(adm.isChecked()){
            Usuario u = new Usuario(l,s,2);
            list.add(u);
        }
        else{
            Usuario u = new Usuario(l,s,1);
            list.add(u);
        }
        Toast.makeText(this, "Usuário cadastrado", Toast.LENGTH_LONG).show();
    }
}
